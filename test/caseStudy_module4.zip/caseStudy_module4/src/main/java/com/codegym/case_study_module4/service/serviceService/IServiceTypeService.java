package com.codegym.case_study_module4.service.serviceService;

import com.codegym.case_study_module4.model.ServiceType;

public interface IServiceTypeService {
    Iterable<ServiceType> findAll();
}
