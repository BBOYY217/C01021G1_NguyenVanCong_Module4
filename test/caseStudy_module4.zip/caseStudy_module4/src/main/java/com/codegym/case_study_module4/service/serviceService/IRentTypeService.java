package com.codegym.case_study_module4.service.serviceService;

import com.codegym.case_study_module4.model.RentType;

import java.util.List;

public interface IRentTypeService {
    Iterable<RentType> findAll();
}
