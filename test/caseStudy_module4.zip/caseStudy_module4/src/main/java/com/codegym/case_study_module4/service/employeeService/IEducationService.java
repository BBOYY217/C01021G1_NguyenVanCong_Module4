package com.codegym.case_study_module4.service.employeeService;

import com.codegym.case_study_module4.model.Education;

public interface IEducationService {
    Iterable<Education> findAll();
}
