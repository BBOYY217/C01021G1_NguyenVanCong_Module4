package com.codegym.case_study_module4.service.employeeService;

import com.codegym.case_study_module4.model.Division;

public interface IDivisionService {
    Iterable<Division> findAll();
}
