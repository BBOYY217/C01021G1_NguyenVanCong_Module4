package com.codegym.case_study_module4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaseStudyModule4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
